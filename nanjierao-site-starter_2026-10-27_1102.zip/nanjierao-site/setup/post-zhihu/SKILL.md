---
name: post-zhihu
description: Publish one of Jimmy's Zhihu answers (a local Markdown draft) as a blog post on nanjierao.github.io, with an English title and summary. Use only when Jimmy runs /post-zhihu.
argument-hint: "[path-to-draft.md] [zhihu-url]"
disable-model-invocation: true
---

Publish the Zhihu answer at `$0` as a blog post. Zhihu URL of the original (optional): `$1`.
Rules come from CLAUDE.md (public repo, content rules, images, git workflow) and DECISIONS D41.

1. **Read the draft.** If `$0` is missing or unreadable, ask for the path. It is Jimmy's own
   writing: keep his words exactly; fix only broken Markdown. If the draft says the answer is
   Zhihu-exclusive or paid (for example 盐选), stop and ask before going on.
2. **Find or create the post.** If a post with the same Zhihu URL already exists, update it
   instead of adding a second one. Otherwise create
   `src/content/blog/<YYYY-MM-DD>-<short-english-slug>/index.md` (the answer's date if the draft
   gives one, otherwise today).
3. **Front matter** (follow the blog schema in the content config; if it differs from this list,
   the schema wins): `title` (Chinese, as written), `title_en` (faithful translation), `date`,
   `lang: zh-CN`, `zhihu_url` (`$1` if given), `summary_en`, `tags` (3–5, English), `draft: false`.
4. **English summary.** 2–3 plain sentences on what the answer argues, and why it matters for
   HCI, AI or learning when the post itself says so. Summarize only what the post says: no new
   claims, numbers, quotations or citations. Show Jimmy `title_en` and `summary_en` and wait for
   his OK or edits.
5. **Images.** Copy every image the draft uses into the post folder and reference it relatively
   (`./name.jpg`) so Astro's image pipeline processes it and strips metadata. Never hot-link
   `zhimg.com`: Zhihu blocks hotlinking. If the draft only has `zhimg.com` links, download those
   images into the post folder; list any that fail. Only Jimmy's own images: ask about
   screenshots or pictures made by other people.
6. **Privacy check.** Report what you find; don't fix it silently:
   - phone numbers, email addresses, street addresses, ID-like numbers;
   - names or @handles of other people (Zhihu users, students, colleagues). Readers' comments may
     be quoted only briefly, as "a Zhihu reader", without usernames;
   - anything in the facts.md §15 categories;
   - location metadata in the original images.
   If anything turns up, stop and ask.
7. **Build and preview.** Run `npm run build`, `npm run check` and `npm run check:privacy`, start
   the dev server, and give Jimmy the local URL of the post. Report what the checks found.
8. **Publish after Jimmy's OK.** Commit (`content: blog post <title_en>`) and push to `main`.
   GitHub Actions publishes the site in a minute or two. Report the live URL
   `https://nanjierao.github.io/blog/<slug>/`.

Copy nothing else from Jimmy's local folders into the repo.
