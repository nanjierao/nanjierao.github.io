# nanjierao.github.io

Source for **https://nanjierao.github.io**, the personal website of Nanjie (Jimmy) Rao, HCI
researcher. Built with Astro, published by GitHub Actions to GitHub Pages, and maintained by
Jimmy with Claude Code. This repository is public.

**Start here:** `docs/SESSION_PROMPTS.md` → S0. Blog posts: `/post-zhihu` in Claude Code.

- `CLAUDE.md` — standing instructions for Claude Code (stack, content/image/AI rules, open-source-first, local git workflow)
- `docs/SITE_PLAN.md` — the plan (v4): intro strip + word cloud + three portals + blog + easter egg, architecture, timeline, Jimmy-only tasks
- `docs/SESSION_PROMPTS.md` — copy-paste prompts for sessions S0–S10, in order
- `docs/DECISIONS.md` — decision log (what was decided, why, status)
- `docs/THIRD_PARTY.md` — vetted open-source projects to adapt, with licenses
- `content/facts.md` — single source of truth for facts and numbers
- `content/wordcloud.yaml` · `qa-library.yaml` · `hand-stories.yaml` · `reflections.yaml` · `ideas.yaml` · `life-portal.md` — content drafts for the homepage and portals
- `source/` — public-safe research materials: dissertation abstract, extraction prompt (App. C), coding-scheme definitions (App. A, no participant quotations), old site, CS-UDT notes
- `public/demos/csudt/` — CS-UDT flood digital twin demo (self-contained HTML, synthetic data)
- `migration/cise/` — redirect files + HOWTO for the old cise.ufl.edu/~nr0 page (`.htaccess` is a hidden file)
- `setup/post-zhihu/` — the `/post-zhihu` command that turns a Zhihu draft into a blog post; S0 moves it to `.claude/skills/post-zhihu/`

Workflow: Claude Code on Jimmy's Mac → local preview → Jimmy's OK → push → GitHub Actions → GitHub Pages.
