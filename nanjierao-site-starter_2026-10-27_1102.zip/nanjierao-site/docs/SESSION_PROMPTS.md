# Session prompts for Claude Code on Jimmy's Mac (v4)

How to run one: open Claude Code on your Mac in `~/Downloads/JobR/nanjierao-site` (after S0 this
folder is the git repository) → paste the prompt → let it work → look at the local preview it
gives you (http://localhost:4321 on the laptop; the "Network" address on your phone, same Wi-Fi)
→ reply with fixes → say "OK, push" → GitHub Actions publishes https://nanjierao.github.io within
a minute or two. Start a fresh conversation for each numbered session.

v4: GitHub Pages, local Claude Code, blog, optional Worker (DECISIONS D37–D48). Paste these
prompts as they are. Don't paste review text or "master prompts" from other assistants: they
carry facts that aren't in `content/facts.md`.

Order: **S0 → S1 → S2 then S3, alongside S4 → S5, S6, S7 → S8 (optional) → S9**, and S10 in
January. Blog posts any time after S1, with `/post-zhihu`.

Every prompt assumes Claude Code reads CLAUDE.md first, including **Open source first**: search,
compare, adapt, credit — don't rebuild what already exists.

Checklist for every session:
- [ ] Looks right on laptop and phone, light and dark
- [ ] Facts match content/facts.md; nothing in the facts.md §15 categories
- [ ] New third-party code is in docs/THIRD_PARTY.md with its license
- [ ] TODO(jimmy) list answered or carried forward
- [ ] `npm run check:privacy` clean (from S1 on) before "OK, push"

---

## S0 — Make this folder the public repository (once, about 15 minutes)

Before: create the GitHub organization `nanjierao` (Free plan) on github.com, and sign in to GitHub
on this Mac yourself (`gh auth login`, or GitHub Desktop).

```
Read CLAUDE.md and docs/SITE_PLAN.md §9 and §16.
Goal: turn this folder into the public repository nanjierao/nanjierao.github.io and switch on
GitHub Pages. Don't install Astro yet; that's S1.
0. Move setup/post-zhihu/ to .claude/skills/post-zhihu/ (that's where Claude Code looks for the
   /post-zhihu command), then remove the empty setup/ folder.
1. Privacy check before anything leaves this Mac: list every file that would be committed
   (respect .gitignore) and search them for phone numbers, email addresses, street addresses,
   ID-like numbers, and the facts.md §15 categories. Check images in source/old-site/img for
   GPS/EXIF. Report what you find, and stop if anything looks private.
2. git init with branch main; first commit "chore: starter kit".
3. If `gh auth status` shows I'm signed in, create the public repository
   nanjierao/nanjierao.github.io and push. Otherwise tell me exactly what to run or click; I sign
   in myself.
4. Add a minimal GitHub Actions workflow that publishes a one-page "coming soon" site to GitHub
   Pages (S1 replaces it with the Astro build), and set the Pages source to GitHub Actions (with
   `gh api` if you can; otherwise tell me the clicks).
5. Confirm https://nanjierao.github.io loads. Report what you did, what the checks found, and
   anything I still need to do.
```

## S1 — Scaffold, classic pages, blog skeleton, v0 live

```
Read CLAUDE.md, docs/SITE_PLAN.md, docs/DECISIONS.md, docs/THIRD_PARTY.md and content/facts.md.
Goal: v0 at https://nanjierao.github.io with the neutral baseline design and real content.
1. Scaffold Astro + TypeScript (strict, static output) at the repository root without deleting
   existing files (CLAUDE.md, docs/, content/, source/, public/demos/, migration/, .claude/).
   Add @astrojs/react, @astrojs/sitemap, Prettier, ESLint, Vitest, Playwright +
   @axe-core/playwright, the npm scripts in CLAUDE.md, and `npm run check:privacy` (repository +
   build output: phone numbers, unexpected email addresses, street addresses, facts.md §15 terms,
   image GPS/EXIF).
2. Deploy: replace the S0 workflow with the official Astro → GitHub Pages workflow (withastro/action
   + actions/deploy-pages; current versions from the Astro docs), on push to main and
   workflow_dispatch, with check, lint, test and check:privacy before the build. site
   'https://nanjierao.github.io', no base. No schedule, no step that commits to main.
3. Content collections: research themes grouped Personal · Embodied · Civic (D45); builds
   (optional hardestBug, D29); talks (dates for time-aware wording, D26); publications (12 items
   from facts.md §6; tldr from the §6 drafts, hidden while marked DRAFT; in-preparation items
   behind a flag that is off); blog (title, title_en, summary_en, date, lang, zhihu_url, tags,
   draft; images beside each post). Vitest content checks.
4. Pages with real content only: Home (temporary until S3: the intro strip from D21 with
   positioning option 4 from facts.md §3 as a placeholder and no status line until §2 has an
   approved one; research themes; "Recent" with dated news, the latest blog post and GitHub
   activity), Research overview + 5 theme pages, Publications, Builds (cards + one page each +
   "On GitHub"), Teaching, CV (HTML; "Download CV (PDF)" only when public/cv/Nanjie_Rao_CV.pdf
   exists, otherwise a TODO), About, Blog index + post layout (English title and summary on top,
   Chinese body with lang="zh-CN", link to the Zhihu original) + RSS, Privacy (placeholder),
   Credits (dependencies + a "How this site was built" stub, D35), 404. Placeholder pages for
   /hands, /ask, /life that say "coming soon".
5. GitHub activity (D40): fetch JimmyRaoUF's public activity and repositories (plus public
   repositories of the nanjierao organization) during the Actions build as the static fallback,
   never committed; refresh in the browser from the public GitHub API with a sessionStorage
   cache; fail quietly.
6. /demos/csudt: simple page linking the two demo files in public/demos/csudt/ (don't modify them).
7. Images from source/old-site/img go into src/assets and through Astro's image pipeline (D31)
   with real alt text. YouTube as click-to-load facades (youtube-nocookie).
8. A small time-aware helper (D26): build-time tense plus a tiny client-side update; unit-test it
   with dates before and after 2026-11-20.
9. SEO basics (canonical https://nanjierao.github.io), JSON-LD Person (sameAs Google Scholar and
   https://github.com/JimmyRaoUF), sitemap, robots.txt. Leave migration/cise/ alone.
10. Light/dark tokens, theme toggle, skip link, visible focus, the footer annotation legend (D30).
Then run everything, start the dev server, give me the URLs to check on laptop and phone, list
every TODO(jimmy)/VERIFY item, and wait for my OK before pushing.
```

## S2 — Design spike: homepage concepts (after S1)

```
Read CLAUDE.md, docs/SITE_PLAN.md §4 and §8, docs/DECISIONS.md (D21, D30), docs/THIRD_PARTY.md,
content/wordcloud.yaml.
Build two (at most three) homepage variants on /lab/a, /lab/b (and /lab/c). Each has, in this
order: the intro strip (D21), the word cloud, the three portal cards (Hands, Ask, Life & You —
placeholders behind them), "Recent", the footer legend, and the bottom-right luopan glyph (the
panel can be a stub).
- Word cloud: start from d3-cloud + motion (recommended). In one variant, try an alternative from
  THIRD_PARTY.md (wordcloud2.js or matter-js floating words). Portal ↔ word linking (hover/focus a
  portal → its words glow and drift toward it; click a word → blurb + link), an HTML-list fallback,
  and a reduced-motion static state.
- On a 390 × 844 phone, the first screen shows the name, the one line, CV / Publications / Email,
  and the top of the cloud.
- Each variant has its own token set (type scale, light/dark colors, spacing). Report WCAG
  contrast ratios. Measure homepage JS (gzipped) and Lighthouse mobile for each variant.
Show me side-by-side screenshots (phone/desktop, light/dark), the local URLs, a metrics table, a
short pros/cons note per variant, and the dependencies each uses with licenses. Don't touch other
pages. After I pick: write docs/DESIGN.md, delete /lab, and wait for my OK before pushing.
```

## S3 — Homepage for real + easter egg + classic polish (after S2)

```
Read CLAUDE.md, docs/DESIGN.md, docs/SITE_PLAN.md §4 and §7, content/wordcloud.yaml,
content/ideas.yaml. Build the homepage from the chosen design: intro strip, word cloud, portals
(pointing to coming-soon pages until the portals exist), "Recent" with time-aware wording (D26),
and the easter egg (luopan glyph → side panel with the three bilingual idea cards;
keyboard-reachable last in tab order; accessible name "Things I want to try next"; hint 未完待续 /
to be continued). Luopan teaser: a cursor-following needle on desktop that settles with a slight
damped spring; on phones, after a tap, DeviceOrientation points it north (iOS permission flow);
static under reduced motion. Apply the design system across all classic pages and the blog
(sidenotes, datasheet cards for builds with the optional "Hardest bug & fix", publication filters
that work without JS, TL;DR lines, print stylesheet for /cv, OG image template). Lighthouse table
for /, /research, /publications, /builds, /blog. Wait for my OK before pushing, then remind me to
run migration/cise/HOWTO.md.
```

## S4 — CS-UDT demo + DTRUE talk page (after S1; alongside S2/S3; due Nov 12)

```
Read CLAUDE.md, docs/SITE_PLAN.md, content/facts.md §5.3, source/csudt/README.md.
1. /demos/csudt explainer in the site design (three channels, convergence rule, quests, what's
   simulated, Irma replay numbers), with launch buttons for the planner dashboard and the citizen
   client (best on a phone). It must open fast on bad conference Wi-Fi: the explainer is static
   with one light preview image (a screenshot of the demo), and the live demo loads only when
   someone taps Launch. Disclose that the demo loads MapLibre and qrcode.js from public CDNs;
   keep OSM attribution.
2. /talks/dtrue-2026: title, authors exactly as facts.md §6 item 10 (VERIFY: if still marked,
   ask me), venue and date (UF Jacksonville campus, Nov 19–20, 2026), abstract from facts.md,
   demo link, slides placeholder, citation. Time-aware wording (D26): "Upcoming oral
   presentation" through Nov 20, then "Presented at DTRUE 2026".
3. QR code SVG for https://nanjierao.github.io/demos/csudt/ (with the trailing slash; high
   contrast, quiet zone, error correction M or higher) at public/talks/dtrue-2026/qr-csudt.svg,
   plus a PNG for slides. Use an existing QR library; note which.
4. Playwright check of both demo files at 390 px width; list problems without editing the files.
Also list what I should keep offline on my laptop for the talk in case the venue Wi-Fi fails.
Wait for my OK before pushing.
```

## S5 — Middle portal: Ask (static)

```
Read CLAUDE.md (AI section), docs/SITE_PLAN.md §5.2, content/qa-library.yaml.
1. Q&A library UI: suggested questions grouped by audience; click shows the stored answer with
   source links instantly. Only items with status: ready.
2. Search: MiniSearch over questions and answers (fuzzy + prefix), in the browser; show the three
   closest answers; if nothing is close, say it isn't covered on this site and show the email
   link. Nothing typed leaves the browser.
3. Live slot: if PUBLIC_API_URL is set at build time, show "Ask anything" and "Fit check" tabs
   (built in S8); otherwise don't render them.
4. Tests: 20 sample questions mapped to the library items they should find; keyboard and
   screen-reader pass; axe.
Wait for my OK before pushing.
```

## S6 — Left portal: Hands

```
Read CLAUDE.md (camera rules), docs/SITE_PLAN.md §5.1, docs/DECISIONS.md (D05–D07, D23),
content/hand-stories.yaml, docs/THIRD_PARTY.md. Don't write a hand tracker or 3D engine: start from
collidingScopes/threejs-handtracking-101 (MIT) — vendor it into src/vendor/ with its LICENSE and a
NOTES.md of changes — and @mediapipe/tasks-vision HandLandmarker with WASM and model self-hosted in
public/mediapipe/.
Build /hands:
1. Scripted first (D23): the page opens playing story 1, with Pip moving to recorded motion
   (public/hands/recordings/<story>.json; keyframed placeholder until recordings exist) and
   captions on. A prominent "Use my hand (camera)" button.
2. Camera mode: request the camera only on that click; on-device only; indicator + stop;
   automatic fallback to scripted mode on denial, error, or < ~15 fps. Load MediaPipe and the model
   on intent (hover/focus/tap of the button) or as an idle prefetch on desktop with a fast
   connection and Save-Data off; never on page load for phones. Phone note: best on a laptop, or
   with the phone propped up.
3. Puppet "Pip" (original, simple geometry or a CC0 model): thumb–index distance → jaw; wrist →
   head position/roll; mouth open-and-close → next caption line; open palm held 1 s → next story.
   Smooth landmarks (One Euro filter or similar — use an existing implementation if available).
4. /hands/record (noindex, unlinked): records landmarks at 30 fps for a chosen story and downloads
   JSON in the playback format.
5. Captions always; optional speech synthesis toggle (off by default); keyboard: Space, →, Esc.
6. "How it works" footer + links to the puppet system and Hands as Narrators.
Lazy-load everything; nothing heavy on other routes. Test both modes on a phone-sized viewport,
and report how many bytes a phone visitor who only watches downloads. Wait for my OK before
pushing.
```

## S7 — Right portal: Life & You (sample people + your own AI)

```
Read CLAUDE.md (AI section; camera and visitor data; images), docs/SITE_PLAN.md §5.3,
docs/DECISIONS.md (D10, D11, D24, D42), content/life-portal.md, content/reflections.yaml,
source/study2-extraction-prompt.md, source/coding-scheme-definitions.md.
Build /life exactly as content/life-portal.md specifies, with the Sample and Your-own-AI modes:
1. Reflections (status: ready only), random; photo reflections rendered with
   collidingScopes/particular-drift (MIT; vendor with LICENSE + NOTES.md; lazy-load WebGL2; static
   image fallback). Photos follow D31.
2. Three sample people (primary button): write the synthetic personas and their pre-computed JSON
   by hand; the whole flow, including the lesson, works with no network. Label them synthetic.
3. Your own AI: consent card + 18+ notice → the asking question → the copyable prompt from
   life-portal.md → a box for the JSON answer, validated against the schema with friendly errors
   → an optional local box for the visitor's records, used only in the browser to check whether
   each grounded quote appears in them → results → the copyable lesson prompt.
4. Results UI with the grounded/inferred convention; confirm/reject; computed Accuracy, Depth,
   Richness, Phase, and "what asking missed", next to the study numbers from facts.md §5.1–5.2 with
   the caveat line and the self-curation note.
5. A Live-mode slot that appears only when PUBLIC_API_URL is set (built in S8).
Tests: the sample people; malformed and oversized JSON; prompt-injection strings inside pasted
JSON rendered as text, never as HTML. Wait for my OK before pushing.
```

## S8 — Live AI through a Cloudflare Worker (optional)

Before: create a free Cloudflare account; claim the API credits; create a Console workspace with a
$180 monthly limit and auto-reload off; create an API key; create a Turnstile widget for
nanjierao.github.io and localhost. You add `ANTHROPIC_API_KEY` and `TURNSTILE_SECRET_KEY` as Worker
secrets yourself in the Cloudflare dashboard. Never paste the key into Claude Code or chat.

```
Read CLAUDE.md (AI section), docs/SITE_PLAN.md §5.2, §5.3, §9 and §10, docs/DECISIONS.md (D09,
D22, D25, D32, D43, D44), content/life-portal.md (prompt specs), content/qa-library.yaml.
1. worker/: a Cloudflare Worker in TypeScript with wrangler and the official @anthropic-ai/sdk:
   POST /ask, /fit, /interests, /lesson. CORS allowlist exactly https://nanjierao.github.io and
   http://localhost:4321 with OPTIONS preflight; Turnstile verification; per-IP limits and global
   daily caps; input limits; max_tokens; model from ANTHROPIC_MODEL (default claude-haiku-5-5;
   confirm model IDs, citations and prompt caching in the current Anthropic docs). The knowledge
   pack comes from https://nanjierao.github.io/ask/knowledge.json (build it in the site), cached.
   STUB mode when no key. No logging of visitor text.
2. Deployment: tell me the simplest path (Cloudflare's Git integration on the worker/ folder, or
   `wrangler deploy` after I run `wrangler login` myself), then give me the workers.dev URL to set
   as the GitHub Actions variable PUBLIC_API_URL, plus PUBLIC_TURNSTILE_SITE_KEY.
3. Site: with PUBLIC_API_URL set, enable the live tabs on /ask (chat with citation chips; Fit check
   with Direct evidence · Transferable foundation · Let's discuss) and the Live mode on /life. On
   any failure, fall back to the static modes with a calm note.
4. tests/assistant-evals.yaml (30 cases from SITE_PLAN §5.2) + a script that runs them against the
   Worker in STUB and live modes. Update /privacy with Anthropic's API data terms from Anthropic's
   current official pages (link them).
Wait for my OK before pushing.
```

## S9 — Audit, credits, polish (late November)

```
Audit against CLAUDE.md: content truth (claim → facts.md line table); the whole public repository
and its history for private material; check:privacy over the build output (HTML, JSON, the
knowledge pack, metadata, PDF text, image GPS/EXIF); axe on every page; Lighthouse mobile per page
type; broken links; JSON-LD and OG; keyboard walkthrough of the homepage cloud, all three portals,
the blog, and the easter egg; camera-denied, GitHub-API-down and Worker-down paths; time-aware
copy with the clock set after 2026-11-20 and after 2027-01-01; if S8 happened, rerun the evals and
test CORS from another origin. Finish /credits ("How this site was built" + every dependency and
vendored project with license and link). Check that migration/cise/ targets still exist. Fix what
you can, list the rest, and wait for my OK before pushing.
```

## S10 — Chinese pages + easter-egg upgrades (Jan 2027)

```
Add /zh versions of the homepage strip, Research overview, About, Builds, and the easter-egg
notebook (already bilingual) with Astro i18n routing and a language switch; link the blog. Use the
Chinese name in facts.md §1. Translate meaning, keep field terms in English where Chinese readers
use them. Don't publish /zh routes until I approve each page. Then propose (don't build) small
interactive teasers for each idea card.
```

## Blog posts (any time after S1)

In Claude Code, in this folder: `/post-zhihu "<path to the draft .md>" <zhihu answer URL>`.
It drafts the English title and summary for your OK, copies the images, runs the privacy check,
shows the local preview, and pushes after you say OK.
