# Decision log

Newest first. Status: **proposed** (drafted for Jimmy, in effect unless he objects) ·
**needs Jimmy** (blocked on his choice) · **accepted** · **superseded**.

## 2026-10-27 — GitHub Pages, local Claude Code, blog, optional Worker

Jimmy wants a site that needs little upkeep and gets updated often, so content matters more than
owning a domain. He will maintain it with Claude Code on his Mac. A second outside review (Gemini
Argon, six points on this switch) is folded in below.

| ID | Decision | Why | Status |
|---|---|---|---|
| D37 | Host on **GitHub Pages** at https://nanjierao.github.io. Repository `nanjierao/nanjierao.github.io` (public) under a free GitHub organization `nanjierao`; Jimmy's personal account `JimmyRaoUF` stays as it is. No custom domain for now; one can be added later, and GitHub then redirects the github.io address to it. | $0 and no server to maintain. The organization gives a URL that matches his scholarly name without renaming his account (after a rename, profile links such as github.com/JimmyRaoUF return 404). GitHub Free publishes Pages only from public repositories. | accepted (supersedes V1-01 hosting and V1-02) |
| D38 | **Claude Code runs locally** on Jimmy's Mac in `~/Downloads/JobR/nanjierao-site`, which becomes the repository. The local dev server is the preview; Claude Code pushes only after Jimmy's OK, and a push publishes. | Simpler than cloud sessions; it can read private sources on his Mac without committing them, and it has full network access. | accepted (replaces claude.ai/code sessions, the GitHub App step and PR previews) |
| D39 | **Public-repository hygiene**: nothing private in files or history. Raw materials that don't belong in public (application materials, participant quotations) were moved out of the repository; a definitions-only coding scheme replaces the appendix; personal wording in CLAUDE.md, facts.md and the docs is now general; image metadata is stripped. `npm run check:privacy` runs before every push and in CI. | Everything in a public repository, including history, is public. | accepted |
| D40 | **GitHub activity** comes from `JimmyRaoUF` (plus the `nanjierao` organization's public repositories): fetched during the Actions build as a static fallback and refreshed in the browser from the public API with a `sessionStorage` cache. No scheduled workflows and no workflow commits to `main`. | Local pushes never hit conflicts with bot commits, and nothing depends on scheduled workflows, which GitHub disables after 60 days without repository activity. | accepted |
| D41 | **Blog** of Jimmy's Zhihu answers (written locally first): posts in `src/content/blog/<slug>/` with `title_en` and a 2–3 sentence `summary_en` that he approves; Chinese body with `lang="zh-CN"`; a link to the Zhihu original; images copied beside the post and processed by the image pipeline (never hot-linked from `zhimg.com`); RSS. Published with the `/post-zhihu` skill. | Content he already writes; the English summaries make it legible to readers who don't read Chinese. | accepted |
| D42 | **AI is static first.** /ask: the reviewed library plus in-browser fuzzy search (MiniSearch). /life: sample people plus "use your own AI" (the visitor runs a prompt in their own assistant and pastes JSON back; everything is computed in the browser, with an optional local check that quoted evidence appears in their records). Fit check exists only in live mode. | Works with no server, no key, and no cost; nothing to break or abuse. | accepted (refines D08, D10, D11, D25) |
| D43 | **Optional live AI (S8)**: one Cloudflare Worker in `worker/` (free plan, workers.dev address) holds the key as a secret and serves /ask, /fit, /interests and /lesson. The site shows live tabs only when `PUBLIC_API_URL` is set and falls back to the static modes on any failure. CORS allowlist: https://nanjierao.github.io and http://localhost:4321; CORS only limits browsers, so Turnstile, rate limits and caps do the protecting. | Keeps the original live features without moving the site. | proposed (Jimmy decides when) |
| D44 | Fit check middle status is named **"Transferable foundation"** (Jimmy's pick). It must still cite a page and carry the inferred mark. | His wording; the rule matters more than the label. | accepted (amends D22) |
| D45 | Research contexts: **Personal · Embodied · Civic**. The umbrella line is still Jimmy's pick (default: his research statement's framing). | His pick. | grouping accepted · umbrella needs Jimmy |
| D46 | **DTRUE 2026**: Jatin Verma is a coauthor (Jimmy confirmed with the organizers), so "sole author" is gone everywhere. Author order, spelling and title stay **VERIFY** until checked against the v2 extended abstract. QR target: https://nanjierao.github.io/demos/csudt/. | The facts changed. | accepted (VERIFY) |
| D47 | The CISE redirect now points to https://nanjierao.github.io/ (run after S3). | New address. | accepted (updates V1-05) |
| D48 | Superseded by this switch: Cloudflare hosting of the site, Cloudflare Email Routing (the public email is now a choice in facts.md §1), `_redirects`, cloud-session and PR-preview steps, and D33's order (now SESSION_PROMPTS v4: S0 → S10). D16, D19 and D20 apply only if S8 happens; the key then lives only as a Worker secret that Jimmy sets himself. | — | — |

### The outside review of this switch (Oct 27): six points

1. Public-repository privacy: adopted (D39).
2. Scheduled workflows must not commit to `main`: adopted (D40).
3. Fetch activity from `JimmyRaoUF`, not from the repository owner: adopted (D40).
4. Blog images and English summaries: adopted (D41), with one change: images go beside the post
   through the image pipeline, not raw into `public/` (D31).
5. CORS, `PUBLIC_API_URL`, and keeping "your own AI" as a permanent mode: adopted (D42, D43). CORS
   is not a security control on its own.
6. Keep `JimmyRaoUF`, use the `nanjierao` organization: agreed (D37).

## 2026-10-24 (night) — Outside review (Gemini Argon) and a faster build

Jimmy had Gemini Argon review v2 of this plan. He also decided the dissertation now needs little
of his time, so Claude Code can build the whole site without the cautious schedule. The useful
parts of the review are folded in below and in SITE_PLAN v3. Its raw text stays out of this repo:
it contains personal details that don't belong in files every session reads.
**Don't paste Gemini's "Master Prompt" into a session.** These docs supersede it; it would mark
drafts as approved and add facts that aren't in `content/facts.md`.

| ID | Decision | Why | Status |
|---|---|---|---|
| D21 | Homepage order: a compact **intro strip** comes first: name (optional pronunciation button, D36), one-line positioning (facts.md §3), status line (facts.md §2, only once Jimmy approves one), and three actions: **CV (PDF)**, **Publications**, **Email**. Small links to Google Scholar and to whichever of ORCID, GitHub and LinkedIn facts.md §13 lists. Then the word cloud and the three portals, then news. The full nav stays in the header. This changes D03's "classic strip below the cloud". | Committees and recruiters get the facts in five seconds; the playful part is one glance lower. | proposed |
| D22 | Fit check statuses: **Direct evidence** (a paper, build or course on this site) · **Related experience** (adjacent work; must cite a page and carry the inferred mark) · **Let's discuss** (not covered on this site; email link). Never claim a skill, tool or experience that facts.md lacks. | A column of "not in public record" reads like a failed checklist. But a stretch label must not become a hallucination generator, which would undercut the research itself. | proposed; middle label renamed by D44 |
| D09 (resolved) | **No logging** of visitor-entered text on any endpoint; no D1 table. Analytics stay cookieless page views. | Visitors paste names, salaries and internal details into chat boxes. Storing none of it keeps the site out of data-controller duties. Reversible later. | proposed (replaces the 30-day log) |
| D23 | /hands opens straight into **scripted mode**: Pip starts story 1 with recorded hand motion, no intro card. A prominent **"Use my hand (camera)"** button takes over. MediaPipe and its model load on intent (hover, focus or tap of that button), or as an idle prefetch on desktop when the connection is fast and Save-Data is off; never on page load for phone visitors. Camera rules (D06) unchanged. Phones get a short note: best on a laptop, or with the phone propped up. | No wait, and no multi-megabyte download for people who only watch. | proposed (changes D07's entry flow) |
| D24 | /life Act 2: **"Try it with a sample person"** is the primary button and **"Use my own text (18+)"** the secondary one. Within own text, the AI-assistant prompt comes first as the easiest option; browsing history is marked "best on a computer". Three synthetic sample people (adults; neutral, varied interests). Act 4 adds the dissertation's own limitation, in its own terms: what you paste is what you chose to share, and Study 2's samples were self-curated too. No Goffman or self-presentation framing; the dissertation says it does not adopt Goffman's model. | Most visitors won't paste personal records, especially on phones. The honest note comes from the dissertation, not from a framework it declined. | proposed (refines D10, D11) |
| D25 | **Graceful degradation** on /api/ask, /api/interests and /api/lesson. A missing key, failed Turnstile check, rate limit, exhausted credits, 4xx/5xx or timeout gives a calm message and the no-API path: on /ask the Q&A library and email; on /life the sample people. Never a raw error. Flags `ASSISTANT_ENABLED` and `LIFE_API_ENABLED` stay off until evals pass. The model ID stays in `ANTHROPIC_MODEL` (Claude Haiku 5.5, `claude-haiku-5-5`, listed in Anthropic's docs and in Jimmy's Console). | Credits run out monthly by design (D16), and the site must still work. | proposed; extended by D42, D43 |
| D26 | **Time-aware copy**: dated items (talks, degree, "new" badges) carry dates in content. Pages pick the tense at build time, and a tiny client-side check updates it between deploys; the build-time text is the no-JS fallback. Example: DTRUE changes from "Upcoming oral presentation" to "Presented at DTRUE 2026" after 2026-11-20. "Ph.D. candidate" becomes "Ph.D." only when facts.md §2 says so. | A site that still says "upcoming" in March looks abandoned. | proposed |
| D27 | Research overview: keep the umbrella from Jimmy's research statement (what an AI can know about a person, by asking or by reading records; how well grounded it is; what it costs in privacy). Group the five theme pages under three contexts: **learner** (interest identification, grounding, teacher support), **body** (hand enactment, puppets, AR glasses, XPRIZE) and **city** (civic digital twins). Gemini's umbrella "Grounding AI in Authentic Human Contexts" is the alternative. Note that "grounded" is a technical term in the dissertation. | One thread through varied work, consistent with the application materials he is sending out. | needs Jimmy; grouping decided by D45 |
| D28 | Publications: a one-sentence **TL;DR** under each first-author paper (drafts in facts.md §6; hidden until approved). A **Working papers** section with the two in-preparation items in facts.md §6 (synthesis: target ACM CHI; survey update: target IEEE TLT), only if Jimmy approves. | Committees read trajectory, and TL;DRs save them time. | TL;DRs proposed · working papers needs Jimmy |
| D29 | Builds datasheets get an optional **"Hardest bug & fix"** field, filled only from facts.md §7 (XPRIZE has one; the others are TODO(jimmy)). | Shows real debugging, not only finished products. | proposed |
| D30 | The site footer carries a one-line legend for the annotation convention: "Solid underline: shown in the source · Dotted: inferred". | Teaches the convention once and repeats the research idea on every page. | proposed |
| D31 | **Photos**: landscapes, objects and Jimmy himself only. No family members, no children, no other people's faces without their consent. Every image goes through Astro's image pipeline from `src/assets/` (never raw in `public/`), with metadata stripped. CI fails if any built image carries GPS or other EXIF location tags. | A particle effect doesn't hide the original file, and phone photos carry location. | proposed |
| D32 | Honest microcopy: loading and status text says what is happening ("Searching this site's pages…"), never more (e.g., not "checking ground truth"). | The assistant cites pages; it does not verify truth. | proposed |
| D33 | **Faster build order** (Jimmy, Oct 24): S1 → S2 ∥ S4 → S3 → S5, S6, S7 (one after another, or overlapping as review time allows) → S8. Still one session = one PR. The DTRUE pages are still due by Nov 12. | Claude Code writes the code; Jimmy's review time is the real limit. | accepted (supersedes D18); superseded by D48 (SESSION_PROMPTS v4) |
| D34 | Gemini's reflection drafts join `content/reflections.yaml` as drafts, with their source marked. One fact fixed: COP 3530's ~150 students are spread across his discussion sections, not one room. Nothing ships until Jimmy marks it ready (D12 unchanged). | His voice, his call. | proposed |
| D35 | /credits gets a short **"How this site was built"** section: facts.md as the single source of truth, PR review of every change, assistant evals, open-source credits, and what Claude Code did. | The process is itself evidence of AI-engineering judgment. | proposed |
| D36 | Optional human touches, built only when Jimmy supplies the asset: a ≤ 2 s name-pronunciation clip in his own voice, with the text "Nanjie Rao — or just Jimmy"; a 饶楠杰 seal from a licensed font or his own artwork; 5-second silent loops for builds (with a poster image; reduced motion shows the poster); a hand-drawn teaching diagram; on /about, HUST "at Yujia Hill (喻家山), Wuhan"; a damped-spring settle for the luopan needle (static under reduced motion). | Memorable without being loud. | proposed (optional) |

### Review points not adopted, or corrected (kept off the site)

- **Goffman / self-presentation as the dissertation's lens.** Ch. 2 says the dissertation does not
  adopt Goffman's model; it takes only the observation that posts are curated for an audience.
- **Grice's maxims and the Johari window as foundations.** The final dissertation cites neither.
  They can be trivia if Jimmy wants them, never "my framework".
- **"Journal pipeline" for the dissertation synthesis.** facts.md says the synthesis targets ACM
  CHI; only the survey update targets a journal (IEEE TLT).
- **Privacy calculus or wearable sensing as dissertation work.** That framing is retired; the
  final dissertation mentions privacy calculus once, as a limitation.
- **Unverified facts:** extra TA courses, Go as a programming language, a Wear OS app. They're
  listed in facts.md §16 until Jimmy confirms them.
- **Worry that `claude-haiku-5-5` is a hallucinated ID.** It isn't (Anthropic docs, Oct 2026);
  the env var stays anyway.
- **Status line "Open to Postdoctoral, Research Scientist, and Faculty opportunities".** It
  advertises faculty roles. Jimmy picks the wording from the options in facts.md §2.
- **Cloudflare settings from the review** ("Pages", build `npm run build`, output `dist`). Use the
  settings the S1 PR lists from the current Astro adapter docs instead.
- **A free .me domain from the student pack as a short link.** Not needed; one domain (plus
  optional jimmyrao.com) is enough.

## 2026-10-24 (evening) — Model

| ID | Decision | Why | Alternatives considered | Status |
|---|---|---|---|---|
| D19 | Default model `claude-haiku-5-5` for /api/ask, /api/interests, /api/lesson (env var `ANTHROPIC_MODEL`), with low effort for chat and lessons. | About 10× cheaper than Haiku 4.5 ($0.10/$0.50 vs. $1/$5 per MTok up to 100k-token prompts) and supported longer (retirement not before Oct 7, 2027; Haiku 4.5's earliest retirement date, Oct 15, 2026, has passed). | Haiku 4.5 (still active); Sonnet 5.5 for Fit check if quality needs it. | proposed (ID re-checked Oct 24 night); applies only if S8 happens |
| D20 | The API key never goes to Claude Code sessions, the repo, or chat. It lives only as a Cloudflare secret, created in the site workspace just before S5. Auto-reload stays off, so usage stops when credits run out. | The site doesn't need the key until S5; less exposure, and no surprise charges. | Adding the key to the cloud environment for live evals (unnecessary: evals run against the preview deployment). | proposed; key = Worker secret set by Jimmy (D48) |

## 2026-10-24 — Homepage portals, open-source-first, easter egg (v2 of the plan)

| ID | Decision | Why | Alternatives considered | Status |
|---|---|---|---|---|
| D01 | **Open source first.** Before building any non-trivial component, search npm/GitHub, compare ≥ 2 candidates (license, maintenance, size, accessibility), record the pick in `docs/THIRD_PARTY.md`, keep upstream LICENSE files, credit on `/credits`. | Jimmy: don't reinvent wheels; combine and adapt good community work. | Writing custom engines (slower, worse). | proposed |
| D02 | Only MIT/BSD/Apache/ISC/CC0/OFL by default; GPL code and non-OSI licenses (e.g., GSAP's) only with Jimmy's OK; unlicensed demos are inspiration only. | A public site redistributes code; GPL obligations and "no license" both bite. `typed.js` turned GPL-3.0 in v3. | — | proposed |
| D03 | Homepage = **dynamic word cloud** (research background) + **three portals**: left **Hands** (technical), middle **Ask** (assistant), right **Life & You** (narrative + live interest-based learning). A plain "classic view" strip (Research · Publications · CV · Builds · Teaching) sits just below, so committees and recruiters never have to play. | Jimmy's concept; the strip protects the audiences who want facts fast. | Classic homepage only (forgettable). | proposed (order changed by D21: intro strip first) |
| D04 | Word cloud: `d3-cloud` layout + `motion` drift. Each word is tagged to a portal; hovering or focusing a portal makes its words glow and drift toward it; clicking a word shows a one-line, fact-checked blurb and link. Also rendered as an HTML list for screen readers; static under reduced motion. Data: `content/wordcloud.yaml`. | Light (homepage JS budget), accessible, and the portal link makes the cloud functional, not decorative. | TagCloud 3D sphere (dated look), three.js particle text (too heavy for the landing page). | proposed |
| D05 | Left portal (**/hands**): adapt **collidingScopes/threejs-handtracking-101** (MIT) + MediaPipe HandLandmarker (Apache-2.0, self-hosted). The visitor's hand becomes the mouth of a sock puppet ("Pip"): thumb–index distance opens the jaw, the wrist moves the head; gestures advance the story. | Fun in five seconds, technically real, and it connects to his puppet system (HCII 2021) and hand-enactment work (ICIDS 2026) without copying either. | Full-body avatars with VRM + kalidokit (heavier; kalidokit unmaintained). | proposed |
| D06 | Camera only after an explicit click; frames processed on-device and never sent anywhere; visible stop button; automatic fallback when denied, unavailable, or slower than ~15 fps. | Privacy, and many visitors will say no. | Prompting on page load (hostile). | proposed |
| D07 | Fallback = **scripted stories played with recorded hand motion**. A hidden `/hands/record` tool lets Jimmy record his own hand landmarks per story (JSON); until then, keyframed motion. Stories in `content/hand-stories.yaml` (3 drafts tied to XPRIZE, Study 1, CS-UDT). | Same rendering pipeline in both modes; the fallback is literally Jimmy's hands telling stories. | A pre-rendered video (not interactive; heavier). | proposed (scripted mode is now the default entry, D23) |
| D08 | Middle portal (**/ask**): a **Q&A library first** (`content/qa-library.yaml`, ~30 reviewed answers shown instantly without an API call), Claude for free text, with the library + site knowledge pack cached, answers cited to site pages, "not in Jimmy's public materials" otherwise. Chat UI: `@assistant-ui/react`; server: official `@anthropic-ai/sdk`; model Haiku 5.5 by default (see D19). | Fast, cheap, reviewable; the API only handles the long tail. | All-API chat (costlier, less controlled). | proposed; static library + search first, live chat optional (D42, D43) |
| D09 | Unanswered questions (only the question text, no IP) can be logged for 30 days, disclosed, so Jimmy can grow the library. | Turns visitor curiosity into better answers. | No logging. | superseded by D09 (resolved): no logging |
| D10 | Right portal (**/life**): Act 1 Jimmy's reflections (particle photos via **collidingScopes/particular-drift**, MIT) → Act 2 visitor consents and shares a little browsing history, posts, or their AI assistant's summary of their interests → Act 3 AI extraction with grounded/inferred units → Act 4 visitor confirms and sees Accuracy/Depth/Richness/Phase next to Jimmy's study numbers → Act 5 a mini-lesson taught through one confirmed interest. Spec: `content/life-portal.md`. | A live, honest demonstration of the dissertation (ask → read records → confirm → teach), using his own published extraction prompt (Appendix C) and coding scheme (Appendix A) instead of inventing new ones. | A static explainer with a fictional student (kept only as the "sample person" fallback). | proposed (sample people come first, D24) |
| D11 | Visitor data on /life: client-side trimming (links → site names; emails/phones removed), sent once to the Claude API, **never stored or logged**; 18+ notice; sample person for anyone who doesn't want to share. | It's the privacy calculus he studies, applied to his own site. | Server-side storage (no reason to keep it). | proposed |
| D12 | Reflections: only Jimmy's words. Seeds in `content/reflections.yaml` come from his dissertation acknowledgments and CV stories; family appears only in general terms he wrote; nothing ships until he marks it ready. | It's his life; drafts save time but must be his voice. | Writing reflections for him (wrong). | needs Jimmy |
| D13 | **Easter egg** at the homepage's bottom-right: a small luopan (compass) glyph, hint "未完待续 / to be continued". It opens a bilingual "Things I want to try" notebook with three idea cards (`content/ideas.yaml`): feng shui × HCI × AI, children and AI, and a personal decision digital twin. It is keyboard-reachable (last in tab order) and announced to screen readers; on phones the luopan can point north via the device compass after permission. | Jimmy's request. Hidden but accessible, so it delights without excluding anyone. | Konami-code-only secret (inaccessible). | proposed |
| D14 | The feng shui card frames feng shui as a cultural design tradition, comparing it with environmental psychology (e.g., prospect–refuge) and studying how people weigh the two. It doesn't present feng shui claims as validated. Cites 刘克明 (2004). | Keeps the idea credible to academic readers while honoring the tradition. | — | proposed |
| D15 | The digital-twin card states the recording-consent constraint (Florida generally requires all parties' consent for private conversations) and a self-only scope. | Avoids suggesting something unlawful. | — | proposed |
| D16 | API spending: one Console workspace for the site with a monthly cap of $180 (Jimmy: the credits have no other use and expire monthly). Safe only while auto-reload stays off and the org holds no purchased credits — then usage simply stops when credits run out. Haiku 5.5 everywhere by default (D19). Turnstile + per-endpoint rate limits (/api/ask, /api/interests, /api/lesson). | Bounded cost; credits refresh monthly. | — | proposed; applies only if S8 happens (D48) |
| D17 | Earlier "Ask or read?" and grounding-audit demos fold into /life (the sample person) — no separate pages. CS-UDT demo and DTRUE talk page stay, due before Nov 12. | Fewer, stronger pieces. | Keeping all demos (dilutes). | proposed |
| D18 | Build order: v0 + classic pages → DTRUE demo (deadline) → /ask → /hands → /life → audit. | Deadline first; then the most useful to recruiters (ask); /life last because it needs the most review. | — | superseded by D33 |

## 2026-10-24 — v1 of the plan

| ID | Decision | Status |
|---|---|---|
| V1-01 | Astro + TypeScript, static pages, React islands, plain CSS tokens; Cloudflare hosting; private GitHub repo. | accepted (hosting and private repo superseded by D37) |
| V1-02 | Domain nanjierao.com (Scholar name); optional jimmyrao.com redirect. | superseded by D37 (nanjierao.github.io; a domain can come later) |
| V1-03 | Design direction "Grounded" (claims carry evidence; grounded vs. inferred marks), with "Lab Bench" datasheet cards for builds; chosen in a design spike. | proposed |
| V1-04 | Facts only from `content/facts.md`; final-dissertation numbers win. | accepted |
| V1-05 | CISE page → 301 redirect after launch (`migration/cise/`). | accepted (target changed by D47; run it right after S3) |
